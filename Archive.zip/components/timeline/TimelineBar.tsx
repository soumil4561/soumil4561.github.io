interface TimelineBarProps {
  className?: string;
}

export function TimelineBar({ className }: TimelineBarProps = {}) {
  return (
    <div
      className={`
        absolute
        left-0
        md:left-1/2
        top-0 bottom-0
        w-px
        bg-border
        ${className}
      `}
    />
  );
}
